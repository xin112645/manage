package com.dww.controller.base;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;

import java.util.UUID;

public class ass<main> {
    public static void main(String[] args) {
        UUID uuid = UUID.randomUUID();
        System.out.println(".{" + uuid.toString() + "}");
    }
}
