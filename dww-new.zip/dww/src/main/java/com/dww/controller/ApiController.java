package com.dww.controller;


import com.dww.controller.base.BaseController;
import com.dww.service.User.ApiSupplementService;
import com.dww.util.PageData;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.*;


@RestController
public class ApiController extends BaseController {

    @Autowired
    private StringRedisTemplate redis;
    @Autowired
    private ApiSupplementService apiSupplementService;

    @PostMapping("redisUser.api")//同步商户
    public String redisUser(){
        /*try {
            List<PageData> list = apiSupplementService.findByproduct(new PageData());
            redis.delete("User:*");
            for (PageData val:list) {
                Object a = val.get("a");
                Object b = val.get("b");
                Object c = val.get("c");
                Object d = val.get("d");
                StringBuffer product =new StringBuffer(a+"_");
                product.append(b+"_");
                product.append(c);
                redis.opsForValue().set("User:"+product,d+"");
            }
        } catch (Exception e) {
            return "error";
        }*/
        return "success";
    }
    @RequestMapping("redisServer.api")//同步支付宝
    public String redisServer(){
        try {
           /*List<PageData> pd = apiSupplementService.findByServerConfig(new PageData());
           List<PageData> byServerAppid = apiSupplementService.findByServerAppid(new PageData());
           redis.delete("WebServer:*");
           Gson json=new Gson();
           for (int i=0;i<=pd.size()-1;i++){
               redis.opsForValue().set("WebServer:"+pd.get(i).get("server_index")+"",pd.get(i).get("server_ip")+"");
               for (int ii=0;ii<=byServerAppid.size()-1;ii++) {
                   Map<String,String> map=new HashMap<>();
                   map.put("id",byServerAppid.get(ii).get("id")+"");
                   map.put("user_code",byServerAppid.get(ii).get("user_code")+"");
                   map.put("APPID",byServerAppid.get(ii).get("APPID")+"");
                   map.put("RSA_PRIVATE_KEY",byServerAppid.get(ii).get("RSA_PRIVATE_KEY")+"");
                   map.put("ALIPAY_PUBLIC_KEY",byServerAppid.get(ii).get("ALIPAY_PUBLIC_KEY")+"");
                   map.put("status","false");
                   redis.opsForValue().set("WebServer:"+i+":"+byServerAppid.get(ii).get("id")+"",json.toJson(map));
               }
           }*/
            IndexController.Web=0;
            IndexController.WebSize=0;
            IndexController.WebGo=false;
        } catch (Exception e) {
            return "error";
        }
        return "success";
    }
    @RequestMapping("verifyingSignature.api")//验证签名
    public String verifyingSignature(){
        PageData pageData = this.getPageData();
        String uuid = redis.opsForValue().get("User:"+pageData.get("productUuid"));
        if(uuid!=null){
            return "success";
        }else {
            return "error";
        }
    }
    @GetMapping("gettext")
    public String gettext(){
        Gson json=new Gson();

        System.out.println("get请求测试"+json.toJson(this.getPageData()));
        return "";
    }
    @PostMapping("posttext")
    public String posttext(){
        Gson json=new Gson();

        System.out.println("post请求测试"+json.toJson(this.getPageData()));
        return "";
    }
    @PostMapping("SqlInsertStar.api")
    public String SqlInsertStar(@RequestHeader("SecretKey")String SecretKey){
        if(SecretKey.equals("Aa12342234")){
            PageData pd = this.getPageData();
            try {
                //apiSupplementService.addSql(this.getPageData());
            } catch (Exception e) {
                return "sql执行异常";
            }
            return "success";
        }else {
            return "error";
        }
    }
}

