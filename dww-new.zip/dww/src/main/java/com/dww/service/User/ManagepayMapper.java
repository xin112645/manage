package com.dww.service.User;

import ch.qos.logback.classic.db.names.TableName;
import net.sf.json.JSONObject;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

public interface ManagepayMapper {




}
