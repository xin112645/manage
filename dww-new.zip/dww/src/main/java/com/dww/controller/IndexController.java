package com.dww.controller;



import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.domain.AlipayTradeWapPayModel;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.alipay.api.request.AlipayTradePayRequest;
import com.alipay.api.request.AlipayTradePrecreateRequest;
import com.alipay.api.request.AlipayTradeWapPayRequest;
import com.alipay.api.response.AlipayTradePagePayResponse;
import com.alipay.api.response.AlipayTradePayResponse;
import com.alipay.api.response.AlipayTradePrecreateResponse;
import com.dww.controller.base.BaseController;

import com.dww.service.User.ApiSupplementService;


import com.dww.util.*;
import com.google.gson.Gson;
import net.sf.json.JSONObject;
import org.apache.activemq.command.ActiveMQQueue;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsMessagingTemplate;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;
import sun.nio.cs.ext.GBK;

import javax.annotation.Resource;
import javax.jms.Destination;
import javax.jms.Topic;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;


@RestController
public class IndexController extends BaseController {
    public static int Web;
    public static int WebSize;
    public static boolean WebGo;
    @Resource
    ActiveMQClient client;

//    @RequestMapping("hello")
//    public void hello(){
//        client.send("abcdefg");
//    }

    @JmsListener(destination = "Order.AliGateWay")
    public void receiveQueue(String msg)throws Exception{
    }

}
